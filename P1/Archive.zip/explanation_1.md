# Data Structure
The cache is a double linked list to allow efficient operation.

# Time Complexity
By using double linked list, this implementation can achieve O(1) time complexity