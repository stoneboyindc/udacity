# Data Structure
linked list

# Time Complexity
Adding a block into a block chain is constant, which is O(1) time complexity
