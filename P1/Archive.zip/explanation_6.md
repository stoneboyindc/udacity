# Data Structure
linked list

# Time Complexity
It requires two loops to calculate the union or intersection of two lists. Given 'n' and 'm' as the sizes of two linked list, 
the time complexity is O(n+m), but can be just denoted as O(n)
