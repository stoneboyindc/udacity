# Data Structure
list is used for simplicity

# Time Complexity
Each directory and file is visited once. Given 'n' as the total number of files and directories, the time complexity is O(n)

# Space Complexity
Given 'n' as the total number of files and directories, the result could be proportional to the total number of files and directories. Therefore the space complexity is O(n)
