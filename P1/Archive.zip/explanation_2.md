# Data Structure
list

# Time Complexity
Each directory and file is visited once. Given 'n' as the total number of files and directories, the time complexity is O(n)