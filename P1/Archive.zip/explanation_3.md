# Data Structure
tuple, list, tree

# Time Complexity
There is a loop in each step to perform the frequency counting/building tree/encoding/decoding. 
Therefore, given 'n' as the length of data, the time complexity is O(n)