# Data Structure
tree

# Time Complexity
Each group and user is visited once by this recursive function. Given 'n' as the total number of groups and users, 
the time complexity is O(n)
